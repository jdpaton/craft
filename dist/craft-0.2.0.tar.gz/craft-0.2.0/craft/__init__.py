from craft.crafty import task, depends
